package com.inn.cafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
